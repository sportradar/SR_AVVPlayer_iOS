//
//  ViewController.swift
//  SR_AVVPlayer_Example
//
//  Created by Andreas Becher on 08.08.19.
//  Copyright © 2019 Sportradar. All rights reserved.
//

import UIKit
import SRAVVPlayer

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, CellDelegate {
    
    let playerContainer = UIView()
    var collectionView : UICollectionView! = nil
    var player : AVVPlayer?
    var activeVideo = ""
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        self.collectionView.register(VideoCollectionViewCell.self, forCellWithReuseIdentifier: "Cell")
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.view.addSubview(collectionView)
        
        var layoutGuide = self.view.layoutMarginsGuide
        if #available(iOS 11.0, *) {
            layoutGuide = self.view.safeAreaLayoutGuide
        }
        
        collectionView.backgroundColor = .red
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        collectionView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        collectionView.topAnchor.constraint(equalTo: layoutGuide.topAnchor).isActive = true
        
        collectionView.widthAnchor.constraint(equalTo:self.view.widthAnchor).isActive = true
        collectionView.heightAnchor.constraint(equalTo: layoutGuide.heightAnchor).isActive = true
        collectionView.reloadData()
        
        playerContainer.backgroundColor = .brown
    }
    
    func setupVideoPlayer(id: String)
    {

        let settings = AVVPlayer.ModeSettings.Inline(autoLandscapeFullscreen: true, //NEEDS TO BE TRUE IN YOUR CASE, otherwise player will change to fullscreen but not to landscape
                                                     containerView: playerContainer,
                                                     appWindow: UIApplication.shared.keyWindow)
        //external Player config
        let source = "YOUR OTT URL"
        
        let source1 = AVVPlayerConfig(streamUrl:"https://wowzaec2demo.streamlock.net/vod-multitrack/_definst_/smil:ElephantsDream/elephantsdream2.smil/playlist.m3u")
        
        if self.player == nil {
            player = AVVPlayerBuilder.shared.createInlinePlayer(config: source1,
                                                                settings: settings)
            _ = player?.add(self) // for observing player events
            player?.configDelegate = self
        }
        else {
            self.player?.resume()
            self.player?.replace(with: source1)
        }
        
        self.player?.start()
    }
    
    private func resetPlayer() {
        self.player?.replace(with: "")
        self.activeVideo = ""
        self.playerContainer.removeFromSuperview()
    }
    
//ALLOWED ORIENTATIONS ARE HANDLED IN APP DELEGATE
    
//    override var shouldAutorotate: Bool
//    {
//        true
//    }
//
//    override var supportedInterfaceOrientations: UIInterfaceOrientationMask
//    {
//       return .portrait
//    }
//

    let source = ["291996","292544","292523","289962","276419","273131","260708","264703","269820"]
    
    //CollectionView Delegate
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return source.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! VideoCollectionViewCell
        let id = source[indexPath.row]
        cell.delegate = self
        cell.videoId = (id,activeVideo)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.view.frame.size.width, height: self.view.frame.size.width/16*9+20)
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        //suspend player when stop displaying cell with active video--> stops auto fullscreen on rotation and also stopps playback
        if let cell = cell as? VideoCollectionViewCell, cell.videoId?.video == activeVideo {
            if case .initializing = self.player?.state.value {
                resetPlayer()
                return
            }
            self.player?.suspend(keepUpExternalPlaybackRoutes: true)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        //resume player when displaying cell with active video! --> activates rotation --> resumes playback
        if let cell = cell as? VideoCollectionViewCell, cell.videoId?.video == activeVideo {
            self.player?.resume()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    //Cell Delegate
    func playButtonClicked(cell: VideoCollectionViewCell, videoId: String) {
        self.activeVideo = videoId
        cell.cellPlayerContainer = playerContainer
        self.setupVideoPlayer(id: videoId)
    }
    
    func injectPlayerContainer(cell: VideoCollectionViewCell) -> UIView {
        return playerContainer
    }
}


//MARK: - Player Config Delegate --> Manipulate external config after loading
extension ViewController : AVVPlayerConfigDelegate
{
    func avvPlayer(_ player: AVVPlayer, provideMutatedConfigFrom config: AVVPlayerConfig) -> AVVPlayerConfig {
        let newConfig = config

        
        newConfig.playerControlsScheme.seekForwardButtonEnabled = true
        newConfig.playerControlsScheme.seekBehindButtonEnabled = true
        newConfig.playerControlsScheme.seekButtonSeconds = 20
        newConfig.playbackOptions.autoplay = true
        return newConfig
    }
}



//MARK: - Player Observer -> Observe Player Events
extension ViewController : AVVPlayerObserver
{
    func avvPlayer(_ player: AVVPlayer, initializesMediaSession session: AVVMediaSession) {
        //information when media session is created --> recommended method to add Media Session Observer
        _ = session.add(self)
    }
    
    func avvPlayer(_ player: AVVPlayer, didFailWith error: AVVError) {
        //error callback
    }
    
}

extension ViewController : AVVMediaSessionObserver
{
    func willPlay(_ mediaSession: AVVMediaSession) {
        //called when Player Starts playback and resumes from paused state
    }
    
    func willClose(_ mediaSession: AVVMediaSession) {
        //called when media Session will be closed
    }
}


protocol CellDelegate {
    func playButtonClicked(cell: VideoCollectionViewCell, videoId: String)
    func injectPlayerContainer(cell: VideoCollectionViewCell) -> UIView
}

class VideoCollectionViewCell : UICollectionViewCell
{
    var cellPlayerContainer : UIView? {
        didSet {
            if let playerContainer = cellPlayerContainer {
                self.addSubview(playerContainer)
                playerContainer.translatesAutoresizingMaskIntoConstraints = false
                playerContainer.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 3).isActive = true
                playerContainer.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -3).isActive = true
                playerContainer.topAnchor.constraint(equalTo: self.topAnchor, constant: 3).isActive = true
                playerContainer.bottomAnchor.constraint(equalTo: self.titleLabel.topAnchor, constant: -3).isActive = true
            }
        }
    }
    
    var videoId : (video: String, active: String)? {
        didSet {
            titleLabel.text = videoId?.video
            if videoId?.video == videoId?.active {
                self.cellPlayerContainer = self.delegate?.injectPlayerContainer(cell: self)
            }
            else if cellPlayerContainer?.superview == self {
                cellPlayerContainer?.removeFromSuperview()
            }
            
        }
    }
    
    var delegate : CellDelegate?
    
    private let titleLabel = UILabel()
    private let playButton = UIButton(type: .system)
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
        self.backgroundColor = .blue
        self.addSubview(titleLabel)
        self.addSubview(playButton)
        playButton.addTarget(self, action: #selector(playButtonClicked), for: .touchUpInside)
        playButton.setTitleColor(.white, for: .normal)
        
        playButton.setTitle("Play Button", for: .normal)
        playButton.translatesAutoresizingMaskIntoConstraints = false
        playButton.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        playButton.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        playButton.heightAnchor.constraint(equalToConstant:44).isActive = true
        
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 3).isActive = true
        titleLabel.heightAnchor.constraint(equalToConstant: 20).isActive = true
        titleLabel.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0).isActive = true
    }
    
    @objc func playButtonClicked() {
        self.delegate?.playButtonClicked(cell: self, videoId: self.videoId!.video)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
