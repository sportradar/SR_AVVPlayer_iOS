#  Getting Started
------

The following listings show you where to start with AVVPlayer. This includes adding AVVPlayer to your existing project as well as creating an AVVPlayer instance and basic usage of the Player.  
</br>

## Adding AVVPlayer to your XCode Workspace

The AVVPlayer SDK can be added to your existing project via cocoapods by adding the following line to your podfile.
```
pod 'AVVPlayer-MARVIN'
```

After adding the AVVPlayer SDK to your project, **import** the Module in your .swift files:
```swift
import SRAVVPlayer
```  
</br>

## AVVPlayerSetup

We recommend to setup the Framework in AppDelegate's **didFinishLaunchingWithOptions**. To setup the SDK you will need a valid **license key** which is associated to your app's bundle
identifier and your domain.
```swift
    let playerSetup = AVVPlayerSetup(domain: nil, licenseKey: "[YOUR_LICENSE_KEY]", chromeCastAppId: "2D8999A3")

AVVPlayer.setup(playerSetup) { (avvError) in
    if avvError == nil
    {
        //player license is validated without error, AVVPlayer can be used now
    }
}
```
</br>

## Create AVVPlayer Instance

To get an instance of AVVPlayer use the shared instance of **AVVPlayerBuilder**. You have to methods available to create your AVVPlayer, which one to use depends on how you are going to use the player.</br></br>
Use **createInlinePlayer** if you need to display the player as a subview of a Viewcontroller ("Youtube" style). If you want the player to open in fullscreen on top of your view stack you are going to use **createPresentationPlayer**. 

```swift
let playerContainer = UIView()
let player : AVVPlayer?

let settings = AVVPlayer.ModeSettings.Inline(autoLandscapeFullscreen: UIDevice.current.userInterfaceIdiom == .phone,
                                             containerView: playerContainer,
                                             appWindow: UIApplication.shared.keyWindow)

let source = "https://wowzaec2demo.streamlock.net/vod-multitrack/_definst_/smil:ElephantsDream/elephantsdream2.smil/playlist.m3u"
player = AVVPlayerBuilder.shared.createInlinePlayer(config: AVVPlayerConfig(streamUrl:source),
                                                    settings: settings)
                                                    
_ = player?.add(self) //add AVVPlayer Observer
player?.start()
```
**AVVPlayerConfig** is used to configure the overall behaviour and setup of the player. In the simplest configuration you will create an **AVVPlayerConfig** instance just by passing the media source url to the config. Check out the Class Reference to see all configuration options available. If you are using Sportsradar OTT Services you might using an external Config. For further details have a look to the External Config Guide.

Implement **AVVPlayerObserver** protocol to get notified on state changes and other events of the player. Add your class as observer, call **.add(self)**.
By calling **start** AVVPlayer starts processing by using the given configuration. 

Pass **AVVPlayer.ModeSettings** to define basic display behaviour of the player. The AVVPlayer's view will be added as a subview to the passed containerView and always equals bounds of that view. With **autoLandscapeFullscreen** set **true**, the player will automatically switch to fullscreen on rotating the device to landscape and will leave fullscreen mode on rotating to portrait. This option only makes sense if the ViewController of your containerView supports portrait only. Note that this feature is only available on iphone.

```swift
override var supportedInterfaceOrientations: UIInterfaceOrientationMask
{
   return .portrait
}
```
