#  External Config
------

If you are using Sportradar OTT Services you probably will load your player configuration from an external source. Therefore simply pass the URI path to the **createInlinePlayer** method. On **start**, AVVPlayer will load the source and parse the response into an instance of **AVVPlayerConfig**.

```swift
let config = "https://cdn.laola1.tv/demo/playerconfig/player-setting.json"
player = AVVPlayerBuilder.shared.createInlinePlayer(config: config,
                                                    settings: settings)
                                                    
player?.start()
```
</br>

## Manipulate external Config

If you need to change some properties of the loaded external config before the player is processing it, you can implement  **AVVPlayerConfigDelegate**. Set the AVVPlayer's **configDelegate** property before calling **start**.

```swift
player?.configDelegate = self
player?.start()
```
When the external config is parsed AVVPlayer will call the following delegate method where you can manipulate the passed config. The following example shows how to configure autoplay. Assume that the external config defines **autoplay** to be *false* and you want the player to start playing immediately. Therefore you set **autoplay** to *true* and return the manipulated config. 
```swift
func avvPlayer(_ player: AVVPlayer, provideMutatedConfigFrom config: AVVPlayerConfig) -> AVVPlayerConfig {
       let newConfig = config
       newConfig.autoplay = true
       return newConfig
}
```
